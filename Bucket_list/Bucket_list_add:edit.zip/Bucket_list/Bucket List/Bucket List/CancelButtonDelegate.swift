//
//  CancelButtonDelegate.swift
//  Bucket List
//
//  Created by Zak Hussain on 9/14/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//

import UIKit

protocol CancelButtonDelegate: class{
    func cancelButtonPressedFrom(controller: UIViewController)
}
