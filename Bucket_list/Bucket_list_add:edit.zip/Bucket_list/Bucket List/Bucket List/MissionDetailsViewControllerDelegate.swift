//
//  MissionDetailsViewControllerDelegate.swift
//  Bucket List
//
//  Created by Zak Hussain on 9/14/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//


import Foundation

protocol MissionDetailsViewControllerDelegate: class {
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishAddingMission mission: String)
    func missionDetailsViewController(controller: MissionDetailsViewController, didFinishEditingMission mission: String, atIndexPath: Int)
}