//
//  MissionDetailsViewController.swift
//  Bucket List
//
//  Created by Zak Hussain on 9/14/16.
//  Copyright © 2016 Zak Hussain. All rights reserved.
//


import UIKit
class MissionDetailsViewController: UITableViewController {
    @IBOutlet weak var newMissionTextField: UITextField!
    weak var delegate: MissionDetailsViewControllerDelegate?
    weak var cancelButtonDelegate: CancelButtonDelegate?
    var missionToEdit: String?
    var missionToEditIndexPath: Int?

    @IBAction func cancelBarButtonPressed(sender: UIBarButtonItem) {
        cancelButtonDelegate?.cancelButtonPressedFrom(self)
    }
    @IBAction func doneBarButtonPressed(sender: UIBarButtonItem) {
        // if we are editing then run the "didFinishEditingMission" method
        if var mission = missionToEdit {
            mission = newMissionTextField.text!
            print("edit: \(mission)")
            delegate?.missionDetailsViewController(self, didFinishEditingMission: mission, atIndexPath: missionToEditIndexPath!)
        } else { // we are adding so run the "didFinishAddingMission" method
            let mission = newMissionTextField.text!
            delegate?.missionDetailsViewController(self, didFinishAddingMission: mission)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        newMissionTextField.text = missionToEdit
    }

}
